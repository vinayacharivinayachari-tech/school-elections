// ----- Users -----
const users = {
  admin: { password: "admin123", role: "admin" },
  teacher1: { password: "pass1", role: "teacher" },
  teacher2: { password: "pass2", role: "teacher" },
  teacher3: { password: "pass3", role: "teacher" },
  teacher4: { password: "pass4", role: "teacher" },
  teacher5: { password: "pass5", role: "teacher" },
  teacher6: { password: "pass6", role: "teacher" },
  teacher7: { password: "pass7", role: "teacher" },
  teacher8: { password: "pass8", role: "teacher" },
  teacher9: { password: "pass9", role: "teacher" },
  teacher10: { password: "pass10", role: "teacher" },
};

// ----- Candidates -----
if (!localStorage.getItem("candidates")) {
  const candidates = [
    { name: "Candidate A", votes: 0 },
    { name: "Candidate B", votes: 0 },
    { name: "Candidate C", votes: 0 }
  ];
  localStorage.setItem("candidates", JSON.stringify(candidates));
}

// ----- Login -----
function login(event) {
  event.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (users[username] && users[username].password === password) {
    localStorage.setItem("loggedUser", username);
    if (users[username].role === "admin") {
      window.location.href = "admin.html";
    } else {
      window.location.href = "teacher.html";
    }
  } else {
    document.getElementById("error-msg").textContent = "Invalid login!";
  }
}

// ----- Logout -----
function logout() {
  localStorage.removeItem("loggedUser");
  window.location.href = "index.html";
}

// ----- Render Candidates (Admin Only) -----
function renderAdminCandidates() {
  const candidates = JSON.parse(localStorage.getItem("candidates"));
  const container = document.getElementById("candidates");
  if (!container) return;

  container.innerHTML = "";
  candidates.forEach((c, i) => {
    container.innerHTML += `
      <div>
        <span>${c.name}</span>
        <input type="number" id="votes-${i}" value="${c.votes}">
        <button onclick="updateVotes(${i})">Update</button>
      </div>
    `;
  });

  renderResults();
}

// ----- Update Votes -----
function updateVotes(index) {
  const candidates = JSON.parse(localStorage.getItem("candidates"));
  const newVotes = parseInt(document.getElementById(`votes-${index}`).value);
  candidates[index].votes = newVotes;
  localStorage.setItem("candidates", JSON.stringify(candidates));
  renderResults();
}

// ----- Render Results (Admin + Teachers) -----
function renderResults() {
  const candidates = JSON.parse(localStorage.getItem("candidates"));
  const container = document.getElementById("results");
  if (!container) return;

  let winner = candidates.reduce((max, c) => (c.votes > max.votes ? c : max), candidates[0]);

  container.innerHTML = "<ul>" + 
    candidates.map(c => `<li>${c.name}: ${c.votes} votes</li>`).join("") + 
    "</ul><h4>Winner: ${winner.name}</h4>";
}

// ----- On Page Load -----
window.onload = function() {
  if (document.getElementById("candidates")) renderAdminCandidates();
  if (document.getElementById("results") && !document.getElementById("candidates")) renderResults();
};
